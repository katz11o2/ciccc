import{y as a}from"./CsTUXKtP.js";a();
